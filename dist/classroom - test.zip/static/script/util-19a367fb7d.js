/**
 * @author luoym
 * @email 13575458746@163.com
 * @descrip 
 * @version v2.0.1
 */
"use strict";window.CONFIG={version:"2.4.2",online:"118.31.22.134:8095/ws",apiOnline:"http://ctest.yilesi.cn"};