/**
 * @author luoym
 * @email 13575458746@163.com
 * @descrip 
 * @version v1.0.0
 */
window.CONFIG={zhu:"192.168.1.138:8091/ws",test:"192.168.1.17:8091/ws",online:"116.62.198.105:8091/ws",apiOnline:"http://c.yilesi.cn"};